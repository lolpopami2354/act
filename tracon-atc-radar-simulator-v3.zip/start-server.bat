@echo off
echo Starting local server for ATC Simulator at http://localhost:8000
start http://localhost:8000
python -m http.server 8000
pause
